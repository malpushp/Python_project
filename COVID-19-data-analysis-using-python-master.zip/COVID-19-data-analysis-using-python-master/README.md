COVID 19 DATA ANALYSIS PROJECT USING PYTHON

Data sets given by coursera (johnhopkins university)

Given in this project two data sets - 
Data set 1 - COVID19 dataset which gives a cumulative rate of postive cases per day in various countries
Data set 2 - Happiness worldwide data set which gives various life factors scored by the people living in each countryaround the globe.

In this project I have merged these two data sets to see if there is any relationship between the spread of corona virus and how happy people are living in that country.

Skills developed in this project:
1. Python programming
2. Data analysis
3. Statistics
4. Seaborn
5. Pandas
6. Numpy
7. Matplotlib



